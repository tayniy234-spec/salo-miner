//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dp5XDMvR.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-TjKhvhfd.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-TjKhvhfd.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CCaMVXRT.js"]
	}
} });
//#endregion
export { tsrStartManifest };
