import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Radio, c as Gem, i as Send, l as CalendarRange, o as Pickaxe, r as Timer, s as Layers, t as Vault, u as ArrowUpRight } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BWgW2fE5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BOT_URL = "https://t.me/LootVaultDexBot?start=ref_6850322528";
var copy = {
	uk: {
		nav: {
			how: "Механіка",
			tower: "Вежа",
			calc: "Темп",
			token: "Токен",
			faq: "Питання"
		},
		live: "Майнер увімкнено",
		kicker: "Кібер-екосистема · TON · Telegram",
		h1: "Майни $LOOT, не виходячи з чату",
		lead: "LootVault — ігрова економіка на блокчейні TON. Відкриваєш бота, запускаєш інтервальний майнінг, а множник росте тільки від холду токена на гаманці — до ×10.",
		cta: "Відкрити бота",
		cta2: "Як рахується темп",
		facts: [
			"до ×10 від холду",
			"100 поверхів вежі",
			"серія 30 днів"
		],
		howTitle: "Чотири кроки до першої сесії",
		howLead: "Окремий застосунок не потрібен. Усе живе в Telegram.",
		steps: [
			{
				title: "Відкрий бота",
				body: "Кнопка веде в LootVaultDexBot. Реферальний код уже в посиланні."
			},
			{
				title: "Запусти майнінг",
				body: "У бронзовій лізі додаток показує старт близько 25 LOOT на годину і ~600 на добу при ×1."
			},
			{
				title: "Тримай $LOOT",
				body: "Ліга, рівень і множник рахуються лише з холду. До 2 рівня в бронзі — +116 LOOT на гаманці."
			},
			{
				title: "Пускай токен у справу",
				body: "Синтез модулів, стейкінг на 30–120 днів або торгівля на STON.fi."
			}
		],
		towerTitle: "П'ять контурів вежі",
		towerLead: "Натисни поверх — це механіка з опису екосистеми, не обіцянка виплати.",
		floors: [
			{
				title: "Інтервальний майнінг",
				body: "LOOT добувається порціями. Холд на гаманці піднімає множник, стеля — ×10."
			},
			{
				title: "Cyber Tower",
				body: "100 модульних поверхів. За описом каналу вся вежа може давати до 1.88M LOOT на добу. Це потужність мережі, не особистий баланс."
			},
			{
				title: "Квантовий синтез",
				body: "Зливай компоненти T1 → T5 і збирай рідкі силові модулі."
			},
			{
				title: "Сховища стейкінгу",
				body: "Фіксовані програми нагород: від 30 до 120 днів."
			},
			{
				title: "Серія 30 днів",
				body: "Заходь щодня — бот видає LOOT, ящики і деталі вищого рівня."
			}
		],
		calcTitle: "Прикинь темп",
		calcLead: "База — 25 LOOT за годину, як у бронзі на ×1. Повзунок лише показує, що робить множник холду.",
		mult: "Множник холду",
		hours: "Годин на добу",
		perHour: "На годину",
		perDay: "На добу",
		perWeek: "На 7 діб",
		bronze: "Бронза",
		calcNote: "Це орієнтир, не прогноз доходу. Формулу задає бот. У долари не переводимо: ціна $LOOT на STON.fi змінюється і може бути нульовою.",
		minerTitle: "Панель сесії",
		minerStatus: "Працює",
		session: "Намайнено на цій сторінці",
		holdNote: "Бронза · рів. 1 · до рів. 2 потрібно +116 LOOT холду",
		tokenKicker: "Службовий токен",
		tokenTitle: "$LOOT крутить сховище",
		tokenLead: "Ним торгують на STON.fi. Усередині екосистеми він іде на розгін вежі, синтез модулів і стейкінг.",
		tokenPoints: [
			"Мережа TON",
			"Торгівля на STON.fi",
			"Буст, синтез, стейкінг"
		],
		faqTitle: "Без туману",
		faqs: [
			{
				q: "Це роздача грошей?",
				a: "Ні. Це ігровий майнінг токена в Telegram-боті. Токен може нічого не коштувати."
			},
			{
				q: "Треба платити на старті?",
				a: "Бот відкривається без депозиту. Вищий множник просить холд $LOOT на гаманці — рівень росте тільки від нього."
			},
			{
				q: "Лічильник на сайті — це мій гаманець?",
				a: "Ні. Панель рахує демо-темп у браузері: 25 LOOT/год помножити на вибраний множник. Баланс бота вона не чіпає."
			},
			{
				q: "Де купити і куди виводити?",
				a: "Офіційний канал називає STON.fi. Вивід робить сам бот. Цей сайт гаманцем не є."
			},
			{
				q: "Чому в посиланні є ref?",
				a: "Це реферальне запрошення. Той, хто поділився лінком, отримує реферальний статус у боті."
			}
		],
		finalTitle: "Вежа стоїть. Майнінг — у боті.",
		finalLead: "Одна кнопка, і ти всередині LootVault.",
		disclaimer: "Не фінансова порада. $LOOT — криптоактив: можна втратити все, що вклав. Нагороди, ліги й виведення визначає бот, не ця сторінка.",
		refLine: "Реферальне посилання · LootVaultDexBot"
	},
	ru: {
		nav: {
			how: "Механика",
			tower: "Башня",
			calc: "Темп",
			token: "Токен",
			faq: "Вопросы"
		},
		live: "Майнер включён",
		kicker: "Кибер-экосистема · TON · Telegram",
		h1: "Майни $LOOT, не выходя из чата",
		lead: "LootVault — игровая экономика на блокчейне TON. Открываешь бота, запускаешь интервальный майнинг, а множитель растёт только от холда токена на кошельке — до ×10.",
		cta: "Открыть бота",
		cta2: "Как считается темп",
		facts: [
			"до ×10 от холда",
			"100 этажей башни",
			"серия 30 дней"
		],
		howTitle: "Четыре шага до первой сессии",
		howLead: "Отдельное приложение не нужно. Всё живёт в Telegram.",
		steps: [
			{
				title: "Открой бота",
				body: "Кнопка ведёт в LootVaultDexBot. Реферальный код уже в ссылке."
			},
			{
				title: "Запусти майнинг",
				body: "В бронзовой лиге приложение показывает старт около 25 LOOT в час и ~600 в сутки при ×1."
			},
			{
				title: "Держи $LOOT",
				body: "Лига, уровень и множитель считаются только с холда. До 2 уровня в бронзе — +116 LOOT на кошельке."
			},
			{
				title: "Пусти токен в дело",
				body: "Синтез модулей, стейкинг на 30–120 дней или торговля на STON.fi."
			}
		],
		towerTitle: "Пять контуров башни",
		towerLead: "Нажми этаж — это механика из описания экосистемы, не обещание выплаты.",
		floors: [
			{
				title: "Интервальный майнинг",
				body: "LOOT добывается порциями. Холд на кошельке поднимает множитель, потолок — ×10."
			},
			{
				title: "Cyber Tower",
				body: "100 модульных этажей. По описанию канала вся башня может давать до 1.88M LOOT в сутки. Это мощность сети, не личный баланс."
			},
			{
				title: "Квантовый синтез",
				body: "Сливай компоненты T1 → T5 и собирай редкие силовые модули."
			},
			{
				title: "Хранилища стейкинга",
				body: "Фиксированные программы наград: от 30 до 120 дней."
			},
			{
				title: "Серия 30 дней",
				body: "Заходи каждый день — бот выдаёт LOOT, ящики и детали высокого уровня."
			}
		],
		calcTitle: "Прикинь темп",
		calcLead: "База — 25 LOOT в час, как в бронзе на ×1. Ползунок только показывает, что делает множитель холда.",
		mult: "Множитель холда",
		hours: "Часов в сутки",
		perHour: "В час",
		perDay: "В сутки",
		perWeek: "За 7 дней",
		bronze: "Бронза",
		calcNote: "Это ориентир, не прогноз дохода. Формулу задаёт бот. В доллары не переводим: цена $LOOT на STON.fi меняется и может быть нулевой.",
		minerTitle: "Панель сессии",
		minerStatus: "Работает",
		session: "Намайнено на этой странице",
		holdNote: "Бронза · ур. 1 · до ур. 2 нужно +116 LOOT холда",
		tokenKicker: "Служебный токен",
		tokenTitle: "$LOOT крутит хранилище",
		tokenLead: "Им торгуют на STON.fi. Внутри экосистемы он идёт на разгон башни, синтез модулей и стейкинг.",
		tokenPoints: [
			"Сеть TON",
			"Торговля на STON.fi",
			"Буст, синтез, стейкинг"
		],
		faqTitle: "Без тумана",
		faqs: [
			{
				q: "Это раздача денег?",
				a: "Нет. Это игровой майнинг токена в Telegram-боте. Токен может ничего не стоить."
			},
			{
				q: "Нужно платить на старте?",
				a: "Бот открывается без депозита. Более высокий множитель просит холд $LOOT на кошельке — уровень растёт только от него."
			},
			{
				q: "Счётчик на сайте — это мой кошелёк?",
				a: "Нет. Панель считает демо-темп в браузере: 25 LOOT/час умножить на выбранный множитель. Баланс бота она не трогает."
			},
			{
				q: "Где купить и куда выводить?",
				a: "Официальный канал называет STON.fi. Вывод делает сам бот. Этот сайт кошельком не является."
			},
			{
				q: "Почему в ссылке есть ref?",
				a: "Это реферальное приглашение. Тот, кто поделился ссылкой, получает реферальный статус в боте."
			}
		],
		finalTitle: "Башня стоит. Майнинг — в боте.",
		finalLead: "Одна кнопка, и ты внутри LootVault.",
		disclaimer: "Не финансовый совет. $LOOT — криптоактив: можно потерять всё, что вложил. Награды, лиги и вывод определяет бот, не эта страница.",
		refLine: "Реферальная ссылка · LootVaultDexBot"
	},
	en: {
		nav: {
			how: "Mechanics",
			tower: "Tower",
			calc: "Pace",
			token: "Token",
			faq: "FAQ"
		},
		live: "Miner is live",
		kicker: "Cyber ecosystem · TON · Telegram",
		h1: "Mine $LOOT without leaving chat",
		lead: "LootVault is a gaming economy on the TON blockchain. Open the bot, start interval mining, and the multiplier climbs only with the token you hold — up to ×10.",
		cta: "Open the bot",
		cta2: "How the pace works",
		facts: [
			"up to ×10 from hold",
			"100 tower floors",
			"30-day streak"
		],
		howTitle: "Four steps to the first session",
		howLead: "No extra app. It all lives in Telegram.",
		steps: [
			{
				title: "Open the bot",
				body: "The button opens LootVaultDexBot. The referral code is already in the link."
			},
			{
				title: "Start mining",
				body: "Bronze league in the app shows about 25 LOOT an hour and ~600 a day at ×1."
			},
			{
				title: "Hold $LOOT",
				body: "League, level, and multiplier come only from wallet hold. Bronze level 2 asks for +116 LOOT."
			},
			{
				title: "Put the token to work",
				body: "Module synthesis, 30–120 day staking, or trading on STON.fi."
			}
		],
		towerTitle: "Five circuits of the tower",
		towerLead: "Tap a floor. This is the ecosystem as described — not a payout promise.",
		floors: [
			{
				title: "Interval mining",
				body: "LOOT is extracted in slices. Wallet hold raises the multiplier, capped at ×10."
			},
			{
				title: "Cyber Tower",
				body: "100 modular floors. The channel describes up to 1.88M LOOT/day for the whole tower — network capacity, not a personal balance."
			},
			{
				title: "Quantum synthesis",
				body: "Merge components from T1 to T5 and build rare power modules."
			},
			{
				title: "Staking vaults",
				body: "Fixed reward programs running 30 to 120 days."
			},
			{
				title: "30-day streak",
				body: "Log in daily for LOOT, crates, and higher-tier parts."
			}
		],
		calcTitle: "Sketch the pace",
		calcLead: "Base rate is 25 LOOT per hour, the bronze ×1 figure. The slider only shows what a hold multiplier does.",
		mult: "Hold multiplier",
		hours: "Hours per day",
		perHour: "Per hour",
		perDay: "Per day",
		perWeek: "Per 7 days",
		bronze: "Bronze",
		calcNote: "An illustration, not an income forecast. The bot owns the formula. We do not convert to dollars: the STON.fi price moves and can be zero.",
		minerTitle: "Session panel",
		minerStatus: "Running",
		session: "Mined on this page",
		holdNote: "Bronze · lvl 1 · lvl 2 needs +116 LOOT held",
		tokenKicker: "Utility token",
		tokenTitle: "$LOOT runs the vault",
		tokenLead: "It trades on STON.fi. Inside the ecosystem it feeds tower overclocking, module synthesis, and staking.",
		tokenPoints: [
			"TON network",
			"Trades on STON.fi",
			"Boost, synthesis, staking"
		],
		faqTitle: "No fog",
		faqs: [
			{
				q: "Is this free money?",
				a: "No. It is in-bot token mining. The token can be worth nothing."
			},
			{
				q: "Do I pay to start?",
				a: "The bot opens with no deposit. A higher multiplier requires holding $LOOT — level comes only from that hold."
			},
			{
				q: "Is the counter my wallet?",
				a: "No. The panel is a browser demo: 25 LOOT/hour times the multiplier you pick. It never touches the bot balance."
			},
			{
				q: "Where do I buy or withdraw?",
				a: "The official channel points to STON.fi. Withdrawals happen in the bot. This site is not a wallet."
			},
			{
				q: "Why does the link say ref?",
				a: "It is a referral invite. The person who shared it gets referral status inside the bot."
			}
		],
		finalTitle: "The tower is up. Mining is in the bot.",
		finalLead: "One button and you are inside LootVault.",
		disclaimer: "Not financial advice. $LOOT is a crypto asset: you can lose everything you put in. Rewards, leagues, and withdrawals are decided by the bot, not this page.",
		refLine: "Referral link · LootVaultDexBot"
	}
};
var locales = {
	uk: "uk-UA",
	ru: "ru-RU",
	en: "en-US"
};
var BASE_PER_HOUR = 25;
var LANGS = [
	"uk",
	"ru",
	"en"
];
var FLOOR_ICONS = [
	Pickaxe,
	Layers,
	Gem,
	Vault,
	CalendarRange
];
function formatLoot(n, locale, digits) {
	return n.toLocaleString(locale, {
		minimumFractionDigits: digits,
		maximumFractionDigits: digits
	});
}
function Spark({ data }) {
	const w = 320;
	const h = 76;
	const min = Math.min(...data);
	const span = Math.max(...data) - min || 1;
	const line = data.map((v, i) => {
		return [i / (data.length - 1) * w, h - (v - min) / span * 66 - 4];
	}).map(([x, y], i) => `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`).join(" ");
	const area = `${line} L${w},${h} L0,${h} Z`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: `0 0 ${w} ${h}`,
		className: "h-16 w-full text-cyan",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: area,
			fill: "currentColor",
			opacity: "0.16"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: line,
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2"
		})]
	});
}
function BotLink({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
		href: BOT_URL,
		target: "_blank",
		rel: "noopener noreferrer",
		className,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {
			className: "size-4",
			"aria-hidden": "true"
		})]
	});
}
var ctaClass = "inline-flex h-12 items-center justify-center gap-2 rounded-full bg-gold px-5 font-display text-sm font-medium text-void transition-opacity hover:opacity-90";
function Site() {
	const [lang, setLang] = (0, import_react.useState)("uk");
	const [mult, setMult] = (0, import_react.useState)(1);
	const [hours, setHours] = (0, import_react.useState)(24);
	const [floor, setFloor] = (0, import_react.useState)(0);
	const [faq, setFaq] = (0, import_react.useState)(0);
	const [mined, setMined] = (0, import_react.useState)(0);
	const [samples, setSamples] = (0, import_react.useState)(() => Array.from({ length: 32 }, () => 0));
	const t = copy[lang];
	const locale = locales[lang];
	(0, import_react.useEffect)(() => {
		const saved = window.localStorage.getItem("lv-lang");
		if (saved === "uk" || saved === "ru" || saved === "en") setLang(saved);
		document.documentElement.lang = saved === "ru" || saved === "en" || saved === "uk" ? saved : "uk";
	}, []);
	(0, import_react.useEffect)(() => {
		document.documentElement.lang = lang;
		window.localStorage.setItem("lv-lang", lang);
	}, [lang]);
	(0, import_react.useEffect)(() => {
		const step = BASE_PER_HOUR * mult / 3600 / 5;
		const id = window.setInterval(() => {
			setMined((v) => v + step);
		}, 200);
		return () => window.clearInterval(id);
	}, [mult]);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => {
			setSamples((prev) => {
				const last = prev[prev.length - 1] ?? 0;
				const next = prev.slice(1);
				next.push(last + BASE_PER_HOUR * mult / 3600);
				return next;
			});
		}, 1e3);
		return () => window.clearInterval(id);
	}, [mult]);
	const perHour = BASE_PER_HOUR * mult;
	const perDay = perHour * hours;
	const perWeek = perHour * hours * 7;
	const stats = (0, import_react.useMemo)(() => [
		{
			label: t.perHour,
			value: formatLoot(perHour, locale, perHour >= 100 ? 0 : 1)
		},
		{
			label: t.perDay,
			value: formatLoot(perDay, locale, 0)
		},
		{
			label: t.perWeek,
			value: formatLoot(perWeek, locale, 0)
		}
	], [
		t.perHour,
		t.perDay,
		t.perWeek,
		perHour,
		perDay,
		perWeek,
		locale
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-svh bg-void text-ivory",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-30 border-b border-line bg-void/90 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-16 max-w-6xl items-center gap-4 px-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#top",
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/art/medallion.jpg",
								alt: "",
								className: "hex size-9 object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-sm font-medium tracking-wide",
								children: "LootVault"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
							className: "ml-auto hidden items-center gap-5 text-sm text-mist md:flex",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#how",
									className: "hover:text-ivory",
									children: t.nav.how
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#tower",
									className: "hover:text-ivory",
									children: t.nav.tower
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#calc",
									className: "hover:text-ivory",
									children: t.nav.calc
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#token",
									className: "hover:text-ivory",
									children: t.nav.token
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#faq",
									className: "hover:text-ivory",
									children: t.nav.faq
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LangSwitch, {
							lang,
							onChange: setLang
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "hidden md:flex md:items-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BotLink, {
								className: ctaClass,
								children: t.cta
							})
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				id: "top",
				className: "pb-24 md:pb-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "relative overflow-hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/art/vault.jpg",
								alt: "Кібер-сховище LootVault: золоті ворота і ціанові промені",
								className: "absolute inset-0 h-full w-full object-cover"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-void/60 md:bg-void/40" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-y-0 left-0 hidden w-3/5 bg-gradient-to-r from-void via-void/80 to-transparent md:block" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative mx-auto grid max-w-6xl gap-6 px-4 py-8 md:grid-cols-12 md:gap-8 md:py-16",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "md:col-span-7",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "mb-4 inline-flex items-center gap-2 text-xs font-medium uppercase tracking-widest text-cyan",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, {
													className: "live-dot size-3.5",
													"aria-hidden": "true"
												}), t.live]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mb-3 text-sm text-gold",
												children: t.kicker
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
												className: "max-w-xl text-4xl leading-tight text-ivory sm:text-5xl",
												children: t.h1
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "md:col-span-5 md:row-span-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MinerCard, {
											t,
											locale,
											mined,
											samples,
											perHour,
											mult
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "md:col-span-7",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "max-w-xl text-base leading-relaxed text-mist",
												children: t.lead
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-6 flex flex-col gap-3 sm:flex-row",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BotLink, {
													className: ctaClass,
													children: t.cta
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
													href: "#calc",
													className: "inline-flex h-12 items-center justify-center gap-2 rounded-full border border-line px-5 text-sm text-ivory hover:border-gold",
													children: [t.cta2, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
														className: "size-4",
														"aria-hidden": "true"
													})]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
												className: "mt-6 flex flex-wrap gap-2",
												children: t.facts.map((fact) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
													className: "rounded-full border border-line bg-ink/80 px-3 py-2 text-xs text-ivory",
													children: fact
												}, fact))
											})
										]
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "how",
						className: "mx-auto max-w-6xl px-4 py-16",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-3xl text-ivory",
								children: t.howTitle
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 max-w-2xl text-mist",
								children: t.howLead
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "mt-8 grid gap-3 md:grid-cols-4",
								children: t.steps.map((step, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "rounded-card border border-line bg-ink p-5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "font-display text-sm text-gold",
											children: ["0", i + 1]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "mt-4 text-lg text-ivory",
											children: step.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm leading-relaxed text-mist",
											children: step.body
										})
									]
								}, step.title))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "tower",
						className: "border-y border-line bg-ink",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto grid max-w-6xl gap-8 px-4 py-16 md:grid-cols-12",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "md:col-span-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-3xl",
									children: t.towerTitle
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-mist",
									children: t.towerLead
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "md:col-span-8",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-col gap-2",
									children: t.floors.map((item, i) => {
										const Icon = FLOOR_ICONS[i] ?? Timer;
										const open = floor === i;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											"aria-expanded": open,
											onClick: () => setFloor(i),
											className: "rounded-card border px-4 py-4 text-left transition-colors " + (open ? "border-gold bg-panel text-ivory" : "border-line bg-void text-mist hover:border-gold-deep"),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
													className: open ? "size-5 text-gold" : "size-5",
													"aria-hidden": "true"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "font-display text-sm text-ivory",
													children: [
														i + 1,
														". ",
														item.title
													]
												})]
											}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mt-3 block text-sm leading-relaxed text-mist",
												children: item.body
											}) : null]
										}, item.title);
									})
								})
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "calc",
						className: "mx-auto grid max-w-6xl gap-8 px-4 py-16 md:grid-cols-12",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "md:col-span-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-3xl",
									children: t.calcTitle
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-mist",
									children: t.calcLead
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-6 text-sm text-mist",
									children: t.calcNote
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-card border border-line bg-ink p-5 md:col-span-7",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									htmlFor: "mult",
									className: "flex items-baseline justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm text-mist",
										children: t.mult
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-display text-2xl tabular-nums text-gold",
										children: mult === 1 ? t.bronze : `×${mult}`
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "mult",
									type: "range",
									min: 1,
									max: 10,
									step: 1,
									value: mult,
									onChange: (e) => setMult(Number(e.target.value))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									htmlFor: "hours",
									className: "mt-2 flex items-baseline justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm text-mist",
										children: t.hours
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-display text-2xl tabular-nums",
										children: hours
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "hours",
									type: "range",
									min: 1,
									max: 24,
									step: 1,
									value: hours,
									onChange: (e) => setHours(Number(e.target.value))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
									className: "mt-4 grid grid-cols-3 gap-2",
									children: stats.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-2xl border border-line bg-void px-3 py-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
												className: "text-xs text-mist",
												children: stat.label
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
												className: "mt-1 font-display text-lg tabular-nums text-ivory sm:text-xl",
												children: stat.value
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
												className: "text-xs text-gold",
												children: "LOOT"
											})
										]
									}, stat.label))
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "token",
						className: "border-t border-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto grid max-w-6xl items-center gap-8 px-4 py-16 md:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/art/medallion.jpg",
								alt: "Золотий шестикутний медальйон LootVault",
								className: "mx-auto w-full max-w-sm rounded-card border border-line object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-cyan",
									children: t.tokenKicker
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-2 text-3xl",
									children: t.tokenTitle
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-mist",
									children: t.tokenLead
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-6 flex flex-col gap-2",
									children: t.tokenPoints.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-center gap-3 text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, {
											className: "size-4 text-gold",
											"aria-hidden": "true"
										}), point]
									}, point))
								})
							] })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "faq",
						className: "mx-auto max-w-6xl px-4 py-16",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-3xl",
							children: t.faqTitle
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-6 divide-y divide-line border-y border-line",
							children: t.faqs.map((item, i) => {
								const open = faq === i;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									"aria-expanded": open,
									onClick: () => setFaq(open ? null : i),
									className: "flex w-full items-center justify-between gap-4 py-4 text-left",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-display text-base text-ivory",
										children: item.q
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-gold",
										"aria-hidden": "true",
										children: open ? "–" : "+"
									})]
								}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "pb-4 text-sm leading-relaxed text-mist",
									children: item.a
								}) : null] }, item.q);
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "bg-gold text-void",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto flex max-w-6xl flex-col items-start gap-5 px-4 py-14 md:flex-row md:items-center md:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-3xl text-void",
								children: t.finalTitle
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-gold-deep",
								children: t.finalLead
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: BOT_URL,
								target: "_blank",
								rel: "noopener noreferrer",
								className: "inline-flex h-12 items-center justify-center gap-2 rounded-full bg-void px-5 font-display text-sm text-gold",
								children: [t.cta, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {
									className: "size-4",
									"aria-hidden": "true"
								})]
							})]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "border-t border-line px-4 py-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col gap-3 text-xs leading-relaxed text-mist",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t.disclaimer }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t.refLine })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-x-0 bottom-0 z-40 border-t border-line bg-void/95 p-3 md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BotLink, {
					className: `${ctaClass} w-full`,
					children: t.cta
				})
			})
		]
	});
}
function LangSwitch({ lang, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "ml-auto flex rounded-full border border-line p-1 md:ml-0",
		role: "group",
		"aria-label": "Language",
		children: LANGS.map((code) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-pressed": lang === code,
			onClick: () => onChange(code),
			className: "h-8 min-w-10 rounded-full px-2 text-xs uppercase " + (lang === code ? "bg-gold text-void" : "text-mist"),
			children: code
		}, code))
	});
}
function MinerCard({ t, locale, mined, samples, perHour, mult }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "relative rounded-card border border-gold/40 bg-ink p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute top-3 left-3 h-4 w-4 border-t border-l border-gold" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute right-3 bottom-3 h-4 w-4 border-r border-b border-gold" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-sm",
					children: t.minerTitle
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "inline-flex items-center gap-2 text-xs text-cyan",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "live-dot size-2 rounded-full bg-cyan" }), t.minerStatus]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-xs text-mist",
				children: t.session
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-4xl tabular-nums text-ivory",
				children: formatLoot(mined, locale, 4)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-gold",
				children: "LOOT"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spark, { data: samples }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex items-center justify-between text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-mist",
					children: [formatLoot(perHour, locale, perHour >= 100 ? 0 : 1), " LOOT / h"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-gold",
					children: mult === 1 ? t.bronze : `×${mult}`
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-xs leading-relaxed text-mist",
				children: t.holdNote
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Site, {});
}
//#endregion
export { Home as component };
