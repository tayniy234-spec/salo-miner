import { createFileRoute } from "@tanstack/react-router";
import { SaloApp } from "@/components/salo-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <SaloApp />;
}
