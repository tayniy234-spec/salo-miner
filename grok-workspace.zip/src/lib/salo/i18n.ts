import type { Lang } from "@/lib/salo/sim";

export type Dict = {
  app: string;
  mine: string;
  tasks: string;
  vault: string;
  settings: string;
  tag: string;
  slice: string;
  dull: string;
  level: string;
  perHour: string;
  knife: string;
  unclaimed: string;
  claim: string;
  toNext: (n: string) => string;
  maxed: string;
  pigs: string;
  pigGo: string;
  pigWait: (m: string) => string;
  offlineTitle: string;
  offlineBody: (n: string) => string;
  offlineOk: string;
  levelUp: (n: number) => string;
  channelTitle: string;
  channelBody: string;
  channelGo: string;
  channelClaim: string;
  channelDone: string;
  dailyTitle: string;
  dailyBody: string;
  dailyClaim: string;
  dailyWait: (t: string) => string;
  streak: (d: number) => string;
  vaultTitle: string;
  vaultLead: string;
  vaultNote: string;
  inMine: string;
  sound: string;
  on: string;
  off: string;
  language: string;
  how: string;
  howBody: string;
};

export const locales: Record<Lang, string> = {
  uk: "uk-UA",
  en: "en-US",
  pl: "pl-PL",
  de: "de-DE",
  ru: "ru-RU",
};

export const langLabel: Record<Lang, string> = {
  uk: "Українська",
  en: "English",
  pl: "Polski",
  de: "Deutsch",
  ru: "Русский",
};

export const copy: Record<Lang, Dict> = {
  uk: {
    app: "$SALO майнер",
    mine: "Нарізка",
    tasks: "Завдання",
    vault: "Комора",
    settings: "Налаштування",
    tag: "Козак ріже. Свині стережуть.",
    slice: "Різати сало",
    dull: "Ніж тупий",
    level: "Рівень",
    perHour: "На годину",
    knife: "Ніж",
    unclaimed: "На столі",
    claim: "У комору",
    toNext: (n) => `До наступного рівня ${n} $SALO`,
    maxed: "Максимальний рівень",
    pigs: "Золоті свині",
    pigGo: "Тицьни золоту",
    pigWait: (m) => `Свині відпочивають ${m} хв`,
    offlineTitle: "Козак не байдикував",
    offlineBody: (n) => `Поки тебе не було, нарізано ${n} $SALO.`,
    offlineOk: "Гаразд",
    levelUp: (n) => `Рівень ${n}`,
    channelTitle: "Канал",
    channelBody:
      "Підпишись на канал і забери 270 $SALO в комору. Один раз. На рівень майнера це не впливає.",
    channelGo: "Відкрити канал",
    channelClaim: "Забрати 270",
    channelDone: "Вже в коморі",
    dailyTitle: "Щоденна нарізка",
    dailyBody:
      "Раз на 24 години. Перший день — 10 $SALO, далі на 10 більше, стеля 300. Пропустив добу — серія спочатку.",
    dailyClaim: "Забрати",
    dailyWait: (t) => `Ще ${t}`,
    streak: (d) => `День ${d}`,
    vaultTitle: "Комора",
    vaultLead: "Тут лежить усе, що ти забрав.",
    vaultNote:
      "$SALO існує тільки в цій грі. Це не USDT і не токен у мережі TRC20 чи ERC20. У долари його не вивести.",
    inMine: "Ще на столі",
    sound: "Звук",
    on: "Увімкнено",
    off: "Вимкнено",
    language: "Мова",
    how: "Як це працює",
    howBody:
      "Рівень 1 дає 0,10 $SALO на годину. Кожен наступний додає ще 0,10, аж до 100 рівня. Рівень росте лише від нарізки майнера: другий після 1 $SALO, далі поріг — квадрат номера. Ніж має 100 різів і сам гостриться. Свині, канал і щоденний бонус падають у комору.",
  },
  en: {
    app: "$SALO miner",
    mine: "Slice",
    tasks: "Tasks",
    vault: "Pantry",
    settings: "Settings",
    tag: "The Cossack slices. The pigs keep watch.",
    slice: "Slice the salo",
    dull: "The knife is dull",
    level: "Level",
    perHour: "Per hour",
    knife: "Knife",
    unclaimed: "On the table",
    claim: "To the pantry",
    toNext: (n) => `${n} $SALO to the next level`,
    maxed: "Max level",
    pigs: "Golden pigs",
    pigGo: "Tap a golden one",
    pigWait: (m) => `Pigs are resting ${m} min`,
    offlineTitle: "The Cossack kept working",
    offlineBody: (n) => `While you were away he sliced ${n} $SALO.`,
    offlineOk: "All right",
    levelUp: (n) => `Level ${n}`,
    channelTitle: "Channel",
    channelBody:
      "Subscribe and take 270 $SALO into the pantry. Once. It does not raise your miner level.",
    channelGo: "Open the channel",
    channelClaim: "Take 270",
    channelDone: "Already in the pantry",
    dailyTitle: "Daily slice",
    dailyBody:
      "Once every 24 hours. Day one is 10 $SALO, then +10, capped at 300. Miss a day and the streak starts over.",
    dailyClaim: "Take",
    dailyWait: (t) => `${t} left`,
    streak: (d) => `Day ${d}`,
    vaultTitle: "Pantry",
    vaultLead: "Everything you stored sits here.",
    vaultNote:
      "$SALO exists only in this game. It is not USDT and not a TRC20 or ERC20 token. It cannot be cashed out.",
    inMine: "Still on the table",
    sound: "Sound",
    on: "On",
    off: "Off",
    language: "Language",
    how: "How it works",
    howBody:
      "Level 1 yields 0.10 $SALO an hour. Each level adds 0.10, up to 100. Level grows only from what the miner slices: level 2 after 1 $SALO, then the threshold is the square of the level number. The knife has 100 cuts and sharpens itself. Pigs, the channel, and the daily bonus go to the pantry.",
  },
  pl: {
    app: "Miner $SALO",
    mine: "Krojenie",
    tasks: "Zadania",
    vault: "Komora",
    settings: "Ustawienia",
    tag: "Kozak kroi. Świnie pilnują.",
    slice: "Kroić salo",
    dull: "Tępy nóż",
    level: "Poziom",
    perHour: "Na godzinę",
    knife: "Nóż",
    unclaimed: "Na stole",
    claim: "Do komory",
    toNext: (n) => `Do następnego poziomu ${n} $SALO`,
    maxed: "Maksymalny poziom",
    pigs: "Złote świnie",
    pigGo: "Stuknij złotą",
    pigWait: (m) => `Świnie odpoczywają ${m} min`,
    offlineTitle: "Kozak nie próżnował",
    offlineBody: (n) => `Gdy cię nie było, nakroił ${n} $SALO.`,
    offlineOk: "Dobrze",
    levelUp: (n) => `Poziom ${n}`,
    channelTitle: "Kanał",
    channelBody:
      "Subskrybuj kanał i odbierz 270 $SALO do komory. Raz. To nie podnosi poziomu minera.",
    channelGo: "Otwórz kanał",
    channelClaim: "Odbierz 270",
    channelDone: "Już w komorze",
    dailyTitle: "Dzienna porcja",
    dailyBody:
      "Raz na 24 godziny. Dzień pierwszy to 10 $SALO, potem +10, sufit 300. Pominięta doba zeruje serię.",
    dailyClaim: "Odbierz",
    dailyWait: (t) => `Jeszcze ${t}`,
    streak: (d) => `Dzień ${d}`,
    vaultTitle: "Komora",
    vaultLead: "Tu leży wszystko, co zabrałeś.",
    vaultNote:
      "$SALO istnieje tylko w grze. To nie USDT i nie token w sieci TRC20 ani ERC20. Nie da się go wypłacić w dolarach.",
    inMine: "Jeszcze na stole",
    sound: "Dźwięk",
    on: "Włączony",
    off: "Wyłączony",
    language: "Język",
    how: "Jak to działa",
    howBody:
      "Poziom 1 daje 0,10 $SALO na godzinę. Każdy kolejny dokłada 0,10, aż do 100. Poziom rośnie tylko od krojenia minera: drugi po 1 $SALO, dalej próg to kwadrat numeru. Nóż ma 100 cięć i sam się ostrzy. Świnie, kanał i bonus dzienny trafiają do komory.",
  },
  de: {
    app: "$SALO-Miner",
    mine: "Schneiden",
    tasks: "Aufgaben",
    vault: "Kammer",
    settings: "Einstellungen",
    tag: "Der Kosak schneidet. Die Schweine wachen.",
    slice: "Salo schneiden",
    dull: "Das Messer ist stumpf",
    level: "Stufe",
    perHour: "Pro Stunde",
    knife: "Messer",
    unclaimed: "Auf dem Tisch",
    claim: "In die Kammer",
    toNext: (n) => `Noch ${n} $SALO bis zur nächsten Stufe`,
    maxed: "Höchste Stufe",
    pigs: "Goldene Schweine",
    pigGo: "Tippe ein goldenes",
    pigWait: (m) => `Die Schweine ruhen ${m} Min`,
    offlineTitle: "Der Kosak hat nicht gefaulenzt",
    offlineBody: (n) => `Während du weg warst, hat er ${n} $SALO geschnitten.`,
    offlineOk: "Gut",
    levelUp: (n) => `Stufe ${n}`,
    channelTitle: "Kanal",
    channelBody:
      "Abonniere den Kanal und hol 270 $SALO in die Kammer. Einmal. Die Minenstufe steigt davon nicht.",
    channelGo: "Kanal öffnen",
    channelClaim: "270 holen",
    channelDone: "Schon in der Kammer",
    dailyTitle: "Tägliche Portion",
    dailyBody:
      "Alle 24 Stunden. Tag eins gibt 10 $SALO, danach +10, Deckel 300. Ein verpasster Tag setzt die Serie zurück.",
    dailyClaim: "Holen",
    dailyWait: (t) => `Noch ${t}`,
    streak: (d) => `Tag ${d}`,
    vaultTitle: "Kammer",
    vaultLead: "Hier liegt alles, was du eingesammelt hast.",
    vaultNote:
      "$SALO gibt es nur in diesem Spiel. Es ist kein USDT und kein TRC20- oder ERC20-Token. Es lässt sich nicht in Dollar auszahlen.",
    inMine: "Noch auf dem Tisch",
    sound: "Ton",
    on: "An",
    off: "Aus",
    language: "Sprache",
    how: "So funktioniert's",
    howBody:
      "Stufe 1 bringt 0,10 $SALO pro Stunde. Jede Stufe legt 0,10 drauf, bis 100. Die Stufe wächst nur durch das Schneiden des Miners: Stufe 2 nach 1 $SALO, danach ist die Schwelle das Quadrat der Nummer. Das Messer hat 100 Schnitte und schärft sich selbst. Schweine, Kanal und Tagesbonus gehen in die Kammer.",
  },
  ru: {
    app: "$SALO майнер",
    mine: "Нарезка",
    tasks: "Задания",
    vault: "Комора",
    settings: "Настройки",
    tag: "Казак режет. Свиньи стерегут.",
    slice: "Резать сало",
    dull: "Нож тупой",
    level: "Уровень",
    perHour: "В час",
    knife: "Нож",
    unclaimed: "На столе",
    claim: "В комору",
    toNext: (n) => `До следующего уровня ${n} $SALO`,
    maxed: "Максимальный уровень",
    pigs: "Золотые свиньи",
    pigGo: "Ткни золотую",
    pigWait: (m) => `Свиньи отдыхают ${m} мин`,
    offlineTitle: "Казак не бездельничал",
    offlineBody: (n) => `Пока тебя не было, нарезано ${n} $SALO.`,
    offlineOk: "Хорошо",
    levelUp: (n) => `Уровень ${n}`,
    channelTitle: "Канал",
    channelBody:
      "Подпишись на канал и забери 270 $SALO в комору. Один раз. На уровень майнера это не влияет.",
    channelGo: "Открыть канал",
    channelClaim: "Забрать 270",
    channelDone: "Уже в коморе",
    dailyTitle: "Ежедневная нарезка",
    dailyBody:
      "Раз в 24 часа. Первый день — 10 $SALO, дальше на 10 больше, потолок 300. Пропустил сутки — серия сначала.",
    dailyClaim: "Забрать",
    dailyWait: (t) => `Ещё ${t}`,
    streak: (d) => `День ${d}`,
    vaultTitle: "Комора",
    vaultLead: "Здесь лежит всё, что ты забрал.",
    vaultNote:
      "$SALO существует только в игре. Это не USDT и не токен в сети TRC20 или ERC20. В доллары его не вывести.",
    inMine: "Ещё на столе",
    sound: "Звук",
    on: "Включён",
    off: "Выключен",
    language: "Язык",
    how: "Как это устроено",
    howBody:
      "Уровень 1 даёт 0,10 $SALO в час. Каждый следующий добавляет ещё 0,10, вплоть до 100. Уровень растёт только от нарезки майнера: второй после 1 $SALO, дальше порог — квадрат номера. У ножа 100 резов, и он сам точится. Свиньи, канал и ежедневный бонус падают в комору.",
  },
};
