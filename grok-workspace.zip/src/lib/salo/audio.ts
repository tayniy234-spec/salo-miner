let ctx: AudioContext | null = null;

function context() {
  if (typeof window === "undefined") return null;
  const Ctor = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctor) return null;
  if (!ctx) ctx = new Ctor();
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

export function unlockAudio() {
  context();
}

function tone(
  enabled: boolean,
  freq: number,
  dur: number,
  type: OscillatorType,
  gain: number,
  slide?: number,
) {
  const audio = context();
  if (!enabled || !audio) return;
  const osc = audio.createOscillator();
  const amp = audio.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, audio.currentTime);
  if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, slide), audio.currentTime + dur);
  amp.gain.setValueAtTime(gain, audio.currentTime);
  amp.gain.exponentialRampToValueAtTime(0.0001, audio.currentTime + dur);
  osc.connect(amp);
  amp.connect(audio.destination);
  osc.start();
  osc.stop(audio.currentTime + dur + 0.02);
}

export function playSlice(enabled: boolean) {
  tone(enabled, 220, 0.09, "triangle", 0.08, 70);
  tone(enabled, 540, 0.05, "square", 0.03, 180);
}

export function playDull(enabled: boolean) {
  tone(enabled, 90, 0.12, "sine", 0.06, 50);
}

export function playPig(enabled: boolean) {
  tone(enabled, 320, 0.1, "sine", 0.07, 180);
  tone(enabled, 480, 0.14, "triangle", 0.05, 240);
}

export function playClaim(enabled: boolean) {
  tone(enabled, 392, 0.12, "triangle", 0.06);
  window.setTimeout(() => tone(enabled, 523, 0.14, "triangle", 0.06), 90);
  window.setTimeout(() => tone(enabled, 659, 0.18, "triangle", 0.05), 180);
}

export function playLevel(enabled: boolean) {
  tone(enabled, 523, 0.1, "square", 0.04);
  window.setTimeout(() => tone(enabled, 659, 0.12, "square", 0.04), 80);
  window.setTimeout(() => tone(enabled, 784, 0.2, "triangle", 0.06), 160);
}

export function playDaily(enabled: boolean) {
  tone(enabled, 440, 0.16, "sine", 0.06);
  window.setTimeout(() => tone(enabled, 554, 0.2, "sine", 0.05), 120);
}
