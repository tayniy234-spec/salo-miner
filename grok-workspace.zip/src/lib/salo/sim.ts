export const MAX_LEVEL = 100;
export const KNIFE_MAX = 100;
export const KNIFE_REGEN_PER_SEC = 1 / 3;
export const SLICE_PER_LEVEL = 0.001;
export const PIG_PER_LEVEL = 0.05;
export const PIG_COOLDOWN_MS = 3 * 60 * 1000;
export const OFFLINE_CAP_MS = 12 * 60 * 60 * 1000;
export const DAY_MS = 24 * 60 * 60 * 1000;
export const CHANNEL_URL = "https://t.me/nasvego777";
export const CHANNEL_REWARD = 270;
export const SAVE_KEY = "salo-miner-v1";

export type Lang = "uk" | "en" | "pl" | "de" | "ru";

export type Save = {
  v: 1;
  lang: Lang;
  sound: boolean;
  mined: number;
  unclaimed: number;
  komora: number;
  knife: number;
  updatedAt: number;
  lastPigAt: number;
  channelOpened: boolean;
  subClaimed: boolean;
  streak: number;
  lastDailyAt: number;
};

export const INITIAL: Save = {
  v: 1,
  lang: "uk",
  sound: true,
  mined: 0,
  unclaimed: 0,
  komora: 0,
  knife: KNIFE_MAX,
  updatedAt: 0,
  lastPigAt: 0,
  channelOpened: false,
  subClaimed: false,
  streak: 0,
  lastDailyAt: 0,
};

export function ratePerHour(level: number) {
  return level * 0.1;
}

export function levelFromMined(mined: number) {
  if (!(mined > 0)) return 1;
  const level = Math.floor(Math.sqrt(mined + 1e-6)) + 1;
  return Math.max(1, Math.min(MAX_LEVEL, level));
}

export function levelProgress(mined: number) {
  const level = levelFromMined(mined);
  if (level >= MAX_LEVEL) return 1;
  const start = (level - 1) ** 2;
  const end = level ** 2;
  return Math.min(1, Math.max(0, (mined - start) / (end - start)));
}

export function saloToNext(mined: number) {
  const level = levelFromMined(mined);
  if (level >= MAX_LEVEL) return 0;
  return Math.max(0, level ** 2 - mined);
}

export function catchUp(save: Save, now: number) {
  if (!save.updatedAt) {
    save.updatedAt = now;
    return 0;
  }
  let left = Math.min(OFFLINE_CAP_MS, Math.max(0, now - save.updatedAt)) / 1000;
  let gained = 0;
  while (left > 0.001) {
    const step = Math.min(left, 1);
    const level = levelFromMined(save.mined);
    const gain = (ratePerHour(level) / 3600) * step;
    save.mined += gain;
    save.unclaimed += gain;
    save.knife = Math.min(KNIFE_MAX, save.knife + step * KNIFE_REGEN_PER_SEC);
    gained += gain;
    left -= step;
  }
  save.updatedAt = now;
  return gained;
}

export function tick(save: Save, dt: number, now: number) {
  const step = Math.min(Math.max(dt, 0), 0.1);
  const level = levelFromMined(save.mined);
  const gain = (ratePerHour(level) / 3600) * step;
  save.mined += gain;
  save.unclaimed += gain;
  save.knife = Math.min(KNIFE_MAX, save.knife + step * KNIFE_REGEN_PER_SEC);
  save.updatedAt = now;
  return gain;
}

export function slice(save: Save) {
  if (save.knife < 1) return 0;
  const level = levelFromMined(save.mined);
  const gain = SLICE_PER_LEVEL * level;
  save.knife -= 1;
  save.mined += gain;
  save.unclaimed += gain;
  return gain;
}

export function claim(save: Save) {
  const amount = save.unclaimed;
  if (amount <= 0) return 0;
  save.komora += amount;
  save.unclaimed = 0;
  return amount;
}

export function tapPig(save: Save, now: number) {
  if (save.lastPigAt && now - save.lastPigAt < PIG_COOLDOWN_MS) return 0;
  const gain = PIG_PER_LEVEL * levelFromMined(save.mined);
  save.komora += gain;
  save.lastPigAt = now;
  return gain;
}

export function pigWaitMs(save: Save, now: number) {
  if (!save.lastPigAt) return 0;
  return Math.max(0, PIG_COOLDOWN_MS - (now - save.lastPigAt));
}

export function peekDaily(save: Save, now: number) {
  if (!save.lastDailyAt) {
    return { ready: true, reward: 10, nextStreak: 1, wait: 0 };
  }
  const elapsed = now - save.lastDailyAt;
  if (elapsed < DAY_MS) {
    return { ready: false, reward: 0, nextStreak: save.streak, wait: DAY_MS - elapsed };
  }
  const nextStreak = elapsed >= 2 * DAY_MS ? 1 : Math.min(30, save.streak + 1);
  return { ready: true, reward: nextStreak * 10, nextStreak, wait: 0 };
}

export function claimDaily(save: Save, now: number) {
  const peek = peekDaily(save, now);
  if (!peek.ready) return 0;
  save.streak = peek.nextStreak;
  save.lastDailyAt = now;
  save.komora += peek.reward;
  return peek.reward;
}

export function claimChannel(save: Save) {
  if (save.subClaimed || !save.channelOpened) return 0;
  save.subClaimed = true;
  save.komora += CHANNEL_REWARD;
  return CHANNEL_REWARD;
}

export function formatSalo(n: number, locale: string) {
  const digits = n < 10 ? 4 : n < 100 ? 2 : 1;
  return n.toLocaleString(locale, {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });
}

export function formatRate(n: number, locale: string) {
  return n.toLocaleString(locale, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function formatWait(ms: number) {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  return `${h}:${String(m).padStart(2, "0")}`;
}
