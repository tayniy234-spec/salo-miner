export const BOT_URL = "https://t.me/LootVaultDexBot?start=ref_6850322528";

export type Lang = "uk" | "ru" | "en";

export type Dict = {
  nav: { how: string; tower: string; calc: string; token: string; faq: string };
  live: string;
  kicker: string;
  h1: string;
  lead: string;
  cta: string;
  cta2: string;
  facts: [string, string, string];
  howTitle: string;
  howLead: string;
  steps: { title: string; body: string }[];
  towerTitle: string;
  towerLead: string;
  floors: { title: string; body: string }[];
  calcTitle: string;
  calcLead: string;
  mult: string;
  hours: string;
  perHour: string;
  perDay: string;
  perWeek: string;
  bronze: string;
  calcNote: string;
  minerTitle: string;
  minerStatus: string;
  session: string;
  holdNote: string;
  tokenKicker: string;
  tokenTitle: string;
  tokenLead: string;
  tokenPoints: string[];
  faqTitle: string;
  faqs: { q: string; a: string }[];
  finalTitle: string;
  finalLead: string;
  disclaimer: string;
  refLine: string;
};

export const copy: Record<Lang, Dict> = {
  uk: {
    nav: { how: "Механіка", tower: "Вежа", calc: "Темп", token: "Токен", faq: "Питання" },
    live: "Майнер увімкнено",
    kicker: "Кібер-екосистема · TON · Telegram",
    h1: "Майни $LOOT, не виходячи з чату",
    lead: "LootVault — ігрова економіка на блокчейні TON. Відкриваєш бота, запускаєш інтервальний майнінг, а множник росте тільки від холду токена на гаманці — до ×10.",
    cta: "Відкрити бота",
    cta2: "Як рахується темп",
    facts: ["до ×10 від холду", "100 поверхів вежі", "серія 30 днів"],
    howTitle: "Чотири кроки до першої сесії",
    howLead: "Окремий застосунок не потрібен. Усе живе в Telegram.",
    steps: [
      {
        title: "Відкрий бота",
        body: "Кнопка веде в LootVaultDexBot. Реферальний код уже в посиланні.",
      },
      {
        title: "Запусти майнінг",
        body: "У бронзовій лізі додаток показує старт близько 25 LOOT на годину і ~600 на добу при ×1.",
      },
      {
        title: "Тримай $LOOT",
        body: "Ліга, рівень і множник рахуються лише з холду. До 2 рівня в бронзі — +116 LOOT на гаманці.",
      },
      {
        title: "Пускай токен у справу",
        body: "Синтез модулів, стейкінг на 30–120 днів або торгівля на STON.fi.",
      },
    ],
    towerTitle: "П'ять контурів вежі",
    towerLead: "Натисни поверх — це механіка з опису екосистеми, не обіцянка виплати.",
    floors: [
      {
        title: "Інтервальний майнінг",
        body: "LOOT добувається порціями. Холд на гаманці піднімає множник, стеля — ×10.",
      },
      {
        title: "Cyber Tower",
        body: "100 модульних поверхів. За описом каналу вся вежа може давати до 1.88M LOOT на добу. Це потужність мережі, не особистий баланс.",
      },
      {
        title: "Квантовий синтез",
        body: "Зливай компоненти T1 → T5 і збирай рідкі силові модулі.",
      },
      {
        title: "Сховища стейкінгу",
        body: "Фіксовані програми нагород: від 30 до 120 днів.",
      },
      {
        title: "Серія 30 днів",
        body: "Заходь щодня — бот видає LOOT, ящики і деталі вищого рівня.",
      },
    ],
    calcTitle: "Прикинь темп",
    calcLead: "База — 25 LOOT за годину, як у бронзі на ×1. Повзунок лише показує, що робить множник холду.",
    mult: "Множник холду",
    hours: "Годин на добу",
    perHour: "На годину",
    perDay: "На добу",
    perWeek: "На 7 діб",
    bronze: "Бронза",
    calcNote:
      "Це орієнтир, не прогноз доходу. Формулу задає бот. У долари не переводимо: ціна $LOOT на STON.fi змінюється і може бути нульовою.",
    minerTitle: "Панель сесії",
    minerStatus: "Працює",
    session: "Намайнено на цій сторінці",
    holdNote: "Бронза · рів. 1 · до рів. 2 потрібно +116 LOOT холду",
    tokenKicker: "Службовий токен",
    tokenTitle: "$LOOT крутить сховище",
    tokenLead:
      "Ним торгують на STON.fi. Усередині екосистеми він іде на розгін вежі, синтез модулів і стейкінг.",
    tokenPoints: ["Мережа TON", "Торгівля на STON.fi", "Буст, синтез, стейкінг"],
    faqTitle: "Без туману",
    faqs: [
      {
        q: "Це роздача грошей?",
        a: "Ні. Це ігровий майнінг токена в Telegram-боті. Токен може нічого не коштувати.",
      },
      {
        q: "Треба платити на старті?",
        a: "Бот відкривається без депозиту. Вищий множник просить холд $LOOT на гаманці — рівень росте тільки від нього.",
      },
      {
        q: "Лічильник на сайті — це мій гаманець?",
        a: "Ні. Панель рахує демо-темп у браузері: 25 LOOT/год помножити на вибраний множник. Баланс бота вона не чіпає.",
      },
      {
        q: "Де купити і куди виводити?",
        a: "Офіційний канал називає STON.fi. Вивід робить сам бот. Цей сайт гаманцем не є.",
      },
      {
        q: "Чому в посиланні є ref?",
        a: "Це реферальне запрошення. Той, хто поділився лінком, отримує реферальний статус у боті.",
      },
    ],
    finalTitle: "Вежа стоїть. Майнінг — у боті.",
    finalLead: "Одна кнопка, і ти всередині LootVault.",
    disclaimer:
      "Не фінансова порада. $LOOT — криптоактив: можна втратити все, що вклав. Нагороди, ліги й виведення визначає бот, не ця сторінка.",
    refLine: "Реферальне посилання · LootVaultDexBot",
  },
  ru: {
    nav: { how: "Механика", tower: "Башня", calc: "Темп", token: "Токен", faq: "Вопросы" },
    live: "Майнер включён",
    kicker: "Кибер-экосистема · TON · Telegram",
    h1: "Майни $LOOT, не выходя из чата",
    lead: "LootVault — игровая экономика на блокчейне TON. Открываешь бота, запускаешь интервальный майнинг, а множитель растёт только от холда токена на кошельке — до ×10.",
    cta: "Открыть бота",
    cta2: "Как считается темп",
    facts: ["до ×10 от холда", "100 этажей башни", "серия 30 дней"],
    howTitle: "Четыре шага до первой сессии",
    howLead: "Отдельное приложение не нужно. Всё живёт в Telegram.",
    steps: [
      {
        title: "Открой бота",
        body: "Кнопка ведёт в LootVaultDexBot. Реферальный код уже в ссылке.",
      },
      {
        title: "Запусти майнинг",
        body: "В бронзовой лиге приложение показывает старт около 25 LOOT в час и ~600 в сутки при ×1.",
      },
      {
        title: "Держи $LOOT",
        body: "Лига, уровень и множитель считаются только с холда. До 2 уровня в бронзе — +116 LOOT на кошельке.",
      },
      {
        title: "Пусти токен в дело",
        body: "Синтез модулей, стейкинг на 30–120 дней или торговля на STON.fi.",
      },
    ],
    towerTitle: "Пять контуров башни",
    towerLead: "Нажми этаж — это механика из описания экосистемы, не обещание выплаты.",
    floors: [
      {
        title: "Интервальный майнинг",
        body: "LOOT добывается порциями. Холд на кошельке поднимает множитель, потолок — ×10.",
      },
      {
        title: "Cyber Tower",
        body: "100 модульных этажей. По описанию канала вся башня может давать до 1.88M LOOT в сутки. Это мощность сети, не личный баланс.",
      },
      {
        title: "Квантовый синтез",
        body: "Сливай компоненты T1 → T5 и собирай редкие силовые модули.",
      },
      {
        title: "Хранилища стейкинга",
        body: "Фиксированные программы наград: от 30 до 120 дней.",
      },
      {
        title: "Серия 30 дней",
        body: "Заходи каждый день — бот выдаёт LOOT, ящики и детали высокого уровня.",
      },
    ],
    calcTitle: "Прикинь темп",
    calcLead: "База — 25 LOOT в час, как в бронзе на ×1. Ползунок только показывает, что делает множитель холда.",
    mult: "Множитель холда",
    hours: "Часов в сутки",
    perHour: "В час",
    perDay: "В сутки",
    perWeek: "За 7 дней",
    bronze: "Бронза",
    calcNote:
      "Это ориентир, не прогноз дохода. Формулу задаёт бот. В доллары не переводим: цена $LOOT на STON.fi меняется и может быть нулевой.",
    minerTitle: "Панель сессии",
    minerStatus: "Работает",
    session: "Намайнено на этой странице",
    holdNote: "Бронза · ур. 1 · до ур. 2 нужно +116 LOOT холда",
    tokenKicker: "Служебный токен",
    tokenTitle: "$LOOT крутит хранилище",
    tokenLead:
      "Им торгуют на STON.fi. Внутри экосистемы он идёт на разгон башни, синтез модулей и стейкинг.",
    tokenPoints: ["Сеть TON", "Торговля на STON.fi", "Буст, синтез, стейкинг"],
    faqTitle: "Без тумана",
    faqs: [
      {
        q: "Это раздача денег?",
        a: "Нет. Это игровой майнинг токена в Telegram-боте. Токен может ничего не стоить.",
      },
      {
        q: "Нужно платить на старте?",
        a: "Бот открывается без депозита. Более высокий множитель просит холд $LOOT на кошельке — уровень растёт только от него.",
      },
      {
        q: "Счётчик на сайте — это мой кошелёк?",
        a: "Нет. Панель считает демо-темп в браузере: 25 LOOT/час умножить на выбранный множитель. Баланс бота она не трогает.",
      },
      {
        q: "Где купить и куда выводить?",
        a: "Официальный канал называет STON.fi. Вывод делает сам бот. Этот сайт кошельком не является.",
      },
      {
        q: "Почему в ссылке есть ref?",
        a: "Это реферальное приглашение. Тот, кто поделился ссылкой, получает реферальный статус в боте.",
      },
    ],
    finalTitle: "Башня стоит. Майнинг — в боте.",
    finalLead: "Одна кнопка, и ты внутри LootVault.",
    disclaimer:
      "Не финансовый совет. $LOOT — криптоактив: можно потерять всё, что вложил. Награды, лиги и вывод определяет бот, не эта страница.",
    refLine: "Реферальная ссылка · LootVaultDexBot",
  },
  en: {
    nav: { how: "Mechanics", tower: "Tower", calc: "Pace", token: "Token", faq: "FAQ" },
    live: "Miner is live",
    kicker: "Cyber ecosystem · TON · Telegram",
    h1: "Mine $LOOT without leaving chat",
    lead: "LootVault is a gaming economy on the TON blockchain. Open the bot, start interval mining, and the multiplier climbs only with the token you hold — up to ×10.",
    cta: "Open the bot",
    cta2: "How the pace works",
    facts: ["up to ×10 from hold", "100 tower floors", "30-day streak"],
    howTitle: "Four steps to the first session",
    howLead: "No extra app. It all lives in Telegram.",
    steps: [
      {
        title: "Open the bot",
        body: "The button opens LootVaultDexBot. The referral code is already in the link.",
      },
      {
        title: "Start mining",
        body: "Bronze league in the app shows about 25 LOOT an hour and ~600 a day at ×1.",
      },
      {
        title: "Hold $LOOT",
        body: "League, level, and multiplier come only from wallet hold. Bronze level 2 asks for +116 LOOT.",
      },
      {
        title: "Put the token to work",
        body: "Module synthesis, 30–120 day staking, or trading on STON.fi.",
      },
    ],
    towerTitle: "Five circuits of the tower",
    towerLead: "Tap a floor. This is the ecosystem as described — not a payout promise.",
    floors: [
      {
        title: "Interval mining",
        body: "LOOT is extracted in slices. Wallet hold raises the multiplier, capped at ×10.",
      },
      {
        title: "Cyber Tower",
        body: "100 modular floors. The channel describes up to 1.88M LOOT/day for the whole tower — network capacity, not a personal balance.",
      },
      {
        title: "Quantum synthesis",
        body: "Merge components from T1 to T5 and build rare power modules.",
      },
      {
        title: "Staking vaults",
        body: "Fixed reward programs running 30 to 120 days.",
      },
      {
        title: "30-day streak",
        body: "Log in daily for LOOT, crates, and higher-tier parts.",
      },
    ],
    calcTitle: "Sketch the pace",
    calcLead: "Base rate is 25 LOOT per hour, the bronze ×1 figure. The slider only shows what a hold multiplier does.",
    mult: "Hold multiplier",
    hours: "Hours per day",
    perHour: "Per hour",
    perDay: "Per day",
    perWeek: "Per 7 days",
    bronze: "Bronze",
    calcNote:
      "An illustration, not an income forecast. The bot owns the formula. We do not convert to dollars: the STON.fi price moves and can be zero.",
    minerTitle: "Session panel",
    minerStatus: "Running",
    session: "Mined on this page",
    holdNote: "Bronze · lvl 1 · lvl 2 needs +116 LOOT held",
    tokenKicker: "Utility token",
    tokenTitle: "$LOOT runs the vault",
    tokenLead:
      "It trades on STON.fi. Inside the ecosystem it feeds tower overclocking, module synthesis, and staking.",
    tokenPoints: ["TON network", "Trades on STON.fi", "Boost, synthesis, staking"],
    faqTitle: "No fog",
    faqs: [
      {
        q: "Is this free money?",
        a: "No. It is in-bot token mining. The token can be worth nothing.",
      },
      {
        q: "Do I pay to start?",
        a: "The bot opens with no deposit. A higher multiplier requires holding $LOOT — level comes only from that hold.",
      },
      {
        q: "Is the counter my wallet?",
        a: "No. The panel is a browser demo: 25 LOOT/hour times the multiplier you pick. It never touches the bot balance.",
      },
      {
        q: "Where do I buy or withdraw?",
        a: "The official channel points to STON.fi. Withdrawals happen in the bot. This site is not a wallet.",
      },
      {
        q: "Why does the link say ref?",
        a: "It is a referral invite. The person who shared it gets referral status inside the bot.",
      },
    ],
    finalTitle: "The tower is up. Mining is in the bot.",
    finalLead: "One button and you are inside LootVault.",
    disclaimer:
      "Not financial advice. $LOOT is a crypto asset: you can lose everything you put in. Rewards, leagues, and withdrawals are decided by the bot, not this page.",
    refLine: "Referral link · LootVaultDexBot",
  },
};

export const locales: Record<Lang, string> = {
  uk: "uk-UA",
  ru: "ru-RU",
  en: "en-US",
};
