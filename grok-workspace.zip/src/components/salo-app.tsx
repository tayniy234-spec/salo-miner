import { useEffect, useRef, useState, type ReactNode } from "react";
import { ListChecks, Settings, Utensils, Volume2, VolumeX, Warehouse } from "lucide-react";
import { playClaim, playDaily, playDull, playLevel, playPig, playSlice, unlockAudio } from "@/lib/salo/audio";
import { copy, langLabel, locales, type Dict } from "@/lib/salo/i18n";
import {
  CHANNEL_URL,
  INITIAL,
  SAVE_KEY,
  catchUp,
  claim,
  claimChannel,
  claimDaily,
  formatRate,
  formatSalo,
  formatWait,
  levelFromMined,
  levelProgress,
  peekDaily,
  pigWaitMs,
  ratePerHour,
  saloToNext,
  slice,
  tapPig,
  tick,
  type Lang,
  type Save,
} from "@/lib/salo/sim";

type Tab = "mine" | "tasks" | "vault" | "settings";
type Floater = { id: number; text: string; x: number };

function readSave(): Save | null {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<Save>;
    if (parsed.v !== 1) return null;
    return { ...INITIAL, ...parsed, v: 1 };
  } catch {
    return null;
  }
}

function writeSave(save: Save) {
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify(save));
  } catch {
    /* private mode */
  }
}

export function SaloApp() {
  const saveRef = useRef<Save>({ ...INITIAL });
  const [save, setSave] = useState<Save>(INITIAL);
  const [now, setNow] = useState(0);
  const [tab, setTab] = useState<Tab>("mine");
  const [banner, setBanner] = useState<string | null>(null);
  const [offline, setOffline] = useState<number | null>(null);
  const [hit, setHit] = useState(false);
  const [floaters, setFloaters] = useState<Floater[]>([]);
  const floatId = useRef(0);
  const bannerTimer = useRef(0);

  const t = copy[save.lang];
  const locale = locales[save.lang];
  const level = levelFromMined(save.mined);
  const progress = levelProgress(save.mined);
  const daily = peekDaily(save, now || Date.now());
  const pigWait = pigWaitMs(save, now || Date.now());
  const pigReady = pigWait === 0;

  function flash(text: string) {
    setBanner(text);
    window.clearTimeout(bannerTimer.current);
    bannerTimer.current = window.setTimeout(() => setBanner(null), 1600);
  }

  function publish() {
    setSave({ ...saveRef.current });
    setNow(Date.now());
  }

  function spawn(text: string) {
    const id = ++floatId.current;
    const x = 28 + Math.random() * 44;
    setFloaters((list) => [...list.slice(-6), { id, text, x }]);
    window.setTimeout(() => {
      setFloaters((list) => list.filter((item) => item.id !== id));
    }, 700);
  }

  useEffect(() => {
    const loaded = readSave() ?? { ...INITIAL };
    const before = levelFromMined(loaded.mined);
    const gain = catchUp(loaded, Date.now());
    const after = levelFromMined(loaded.mined);
    saveRef.current = loaded;
    setSave({ ...loaded });
    setNow(Date.now());
    if (gain >= 0.01) setOffline(gain);
    if (after > before) setBanner(copy[loaded.lang].levelUp(after));
    document.documentElement.lang = loaded.lang;

    let last = performance.now();
    let acc = 0;
    let writeAcc = 0;
    let frame = 0;
    const loop = (stamp: number) => {
      const dt = Math.min(0.1, (stamp - last) / 1000);
      last = stamp;
      const prev = levelFromMined(saveRef.current.mined);
      tick(saveRef.current, dt, Date.now());
      const next = levelFromMined(saveRef.current.mined);
      if (next > prev) {
        setBanner(copy[saveRef.current.lang].levelUp(next));
        playLevel(saveRef.current.sound);
      }
      acc += dt;
      writeAcc += dt;
      if (acc >= 0.25) {
        acc = 0;
        setSave({ ...saveRef.current });
        setNow(Date.now());
      }
      if (writeAcc >= 2) {
        writeAcc = 0;
        writeSave(saveRef.current);
      }
      frame = requestAnimationFrame(loop);
    };
    frame = requestAnimationFrame(loop);

    const onGesture = () => unlockAudio();
    const onHide = () => {
      if (document.visibilityState === "hidden") writeSave(saveRef.current);
    };
    window.addEventListener("pointerdown", onGesture);
    document.addEventListener("visibilitychange", onHide);

    const tgWindow = window as unknown as {
      Telegram?: { WebApp?: { ready: () => void; expand: () => void; setHeaderColor?: (c: string) => void; setBackgroundColor?: (c: string) => void } };
    };
    const openTelegram = () => {
      const tg = tgWindow.Telegram?.WebApp;
      if (!tg) return;
      tg.ready();
      tg.expand();
      tg.setHeaderColor?.("#140e0a");
      tg.setBackgroundColor?.("#140e0a");
    };
    if (tgWindow.Telegram?.WebApp) openTelegram();
    else {
      const script = document.createElement("script");
      script.src = "https://telegram.org/js/telegram-web-app.js";
      script.async = true;
      script.onload = openTelegram;
      document.head.appendChild(script);
    }

    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("pointerdown", onGesture);
      document.removeEventListener("visibilitychange", onHide);
      writeSave(saveRef.current);
    };
  }, []);

  function onSlice() {
    unlockAudio();
    const prev = levelFromMined(saveRef.current.mined);
    const gain = slice(saveRef.current);
    if (gain <= 0) {
      playDull(saveRef.current.sound);
      flash(t.dull);
      return;
    }
    const next = levelFromMined(saveRef.current.mined);
    playSlice(saveRef.current.sound);
    if (next > prev) {
      playLevel(saveRef.current.sound);
      flash(t.levelUp(next));
    }
    navigator.vibrate?.(10);
    setHit(true);
    window.setTimeout(() => setHit(false), 160);
    spawn(`+${formatSalo(gain, locale)}`);
    publish();
    writeSave(saveRef.current);
  }

  function onPig() {
    unlockAudio();
    const gain = tapPig(saveRef.current, Date.now());
    if (gain <= 0) {
      const mins = Math.max(1, Math.ceil(pigWaitMs(saveRef.current, Date.now()) / 60000));
      flash(t.pigWait(String(mins)));
      return;
    }
    playPig(saveRef.current.sound);
    navigator.vibrate?.(16);
    flash(`+${formatSalo(gain, locale)}`);
    publish();
    writeSave(saveRef.current);
  }

  function onClaim() {
    const amount = claim(saveRef.current);
    if (amount <= 0) return;
    unlockAudio();
    playClaim(saveRef.current.sound);
    flash(`+${formatSalo(amount, locale)}`);
    publish();
    writeSave(saveRef.current);
  }

  function onDaily() {
    const amount = claimDaily(saveRef.current, Date.now());
    if (amount <= 0) return;
    unlockAudio();
    playDaily(saveRef.current.sound);
    flash(`+${formatSalo(amount, locale)}`);
    publish();
    writeSave(saveRef.current);
  }

  function onChannel() {
    const amount = claimChannel(saveRef.current);
    if (amount <= 0) return;
    unlockAudio();
    playClaim(saveRef.current.sound);
    flash(`+${formatSalo(amount, locale)}`);
    publish();
    writeSave(saveRef.current);
  }

  function setLang(lang: Lang) {
    saveRef.current.lang = lang;
    document.documentElement.lang = lang;
    publish();
    writeSave(saveRef.current);
  }

  function toggleSound() {
    saveRef.current.sound = !saveRef.current.sound;
    if (saveRef.current.sound) {
      unlockAudio();
      playSlice(true);
    }
    publish();
    writeSave(saveRef.current);
  }

  return (
    <div className="h-svh bg-wood text-cream">
      <div className="mx-auto flex h-full max-w-xl flex-col">
        <div className="stitch" />
        <header className="flex items-center gap-3 px-4 py-3">
          <div className="min-w-0">
            <h1 className="text-xl text-cream">{t.app}</h1>
            <p className="truncate text-xs text-mist">{t.tag}</p>
          </div>
          <p className="ml-auto rounded-full bg-gold px-3 py-2 font-display text-xs text-wood">
            {t.level} {level}
          </p>
        </header>
        {banner ? (
          <p className="mx-4 mb-2 rounded-full bg-thread px-3 py-2 text-center text-sm text-cream" role="status">
            {banner}
          </p>
        ) : null}

        <div className="flex-1 overflow-y-auto px-4 pb-4">
          {tab === "mine" ? (
            <MineScreen
              t={t}
              locale={locale}
              level={level}
              progress={progress}
              mined={save.mined}
              unclaimed={save.unclaimed}
              knife={save.knife}
              hit={hit}
              floaters={floaters}
              pigReady={pigReady}
              pigWait={pigWait}
              onSlice={onSlice}
              onPig={onPig}
              onClaim={onClaim}
            />
          ) : null}
          {tab === "tasks" ? (
            <TasksScreen
              t={t}
              locale={locale}
              opened={save.channelOpened}
              claimed={save.subClaimed}
              daily={daily}
              onOpen={() => {
                saveRef.current.channelOpened = true;
                publish();
                writeSave(saveRef.current);
              }}
              onChannel={onChannel}
              onDaily={onDaily}
            />
          ) : null}
          {tab === "vault" ? (
            <VaultScreen t={t} locale={locale} komora={save.komora} unclaimed={save.unclaimed} onClaim={onClaim} />
          ) : null}
          {tab === "settings" ? (
            <SettingsScreen t={t} lang={save.lang} sound={save.sound} onLang={setLang} onSound={toggleSound} />
          ) : null}
        </div>

        <nav className="dock grid grid-cols-4 border-t border-line bg-bark" aria-label={t.app}>
          <DockButton active={tab === "mine"} label={t.mine} onClick={() => setTab("mine")}>
            <Utensils className="size-5" aria-hidden="true" />
          </DockButton>
          <DockButton active={tab === "tasks"} label={t.tasks} onClick={() => setTab("tasks")}>
            <ListChecks className="size-5" aria-hidden="true" />
          </DockButton>
          <DockButton active={tab === "vault"} label={t.vault} onClick={() => setTab("vault")}>
            <Warehouse className="size-5" aria-hidden="true" />
          </DockButton>
          <DockButton active={tab === "settings"} label={t.settings} onClick={() => setTab("settings")}>
            <Settings className="size-5" aria-hidden="true" />
          </DockButton>
        </nav>
      </div>

      {offline !== null ? (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-wood/80 px-4 pb-8 sm:items-center">
          <div className="w-full max-w-xl rounded-2xl border border-line bg-bark p-5" role="dialog" aria-labelledby="offline-title">
            <h2 id="offline-title" className="text-2xl">
              {t.offlineTitle}
            </h2>
            <p className="mt-2 text-sm text-mist">{t.offlineBody(formatSalo(offline, locale))}</p>
            <button
              type="button"
              className="mt-5 h-12 w-full rounded-full bg-gold font-display text-sm text-wood"
              onClick={() => setOffline(null)}
            >
              {t.offlineOk}
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function MineScreen({
  t,
  locale,
  level,
  progress,
  mined,
  unclaimed,
  knife,
  hit,
  floaters,
  pigReady,
  pigWait,
  onSlice,
  onPig,
  onClaim,
}: {
  t: Dict;
  locale: string;
  level: number;
  progress: number;
  mined: number;
  unclaimed: number;
  knife: number;
  hit: boolean;
  floaters: Floater[];
  pigReady: boolean;
  pigWait: number;
  onSlice: () => void;
  onPig: () => void;
  onClaim: () => void;
}) {
  const mins = Math.max(1, Math.ceil(pigWait / 60000));
  return (
    <div className="flex flex-col gap-3">
      <button
        type="button"
        className={`slice-btn relative overflow-hidden rounded-2xl border border-line ${hit ? "pop" : ""}`}
        onClick={onSlice}
        aria-label={t.slice}
      >
        <img src="/art/cossack.jpg" alt="" className="h-80 w-full object-cover object-top" />
        <span className="absolute inset-x-0 bottom-0 bg-wood/80 px-4 py-3 text-left">
          <span className="block font-display text-sm text-gold">{t.slice}</span>
          <span className="block text-xs text-mist">{t.knife} {Math.floor(knife)}/100</span>
        </span>
        {floaters.map((item) => (
          <span
            key={item.id}
            className="floater pointer-events-none absolute font-display text-sm text-gold"
            style={{ left: `${item.x}%`, top: "28%" }}
          >
            {item.text}
          </span>
        ))}
      </button>

      <div className="grid grid-cols-3 gap-2">
        <Stat label={t.unclaimed} value={formatSalo(unclaimed, locale)} />
        <Stat label={t.perHour} value={formatRate(ratePerHour(level), locale)} />
        <Stat label={t.level} value={String(level)} />
      </div>

      <div className="rounded-2xl border border-line bg-bark px-3 py-3">
        <div className="mb-2 h-2 overflow-hidden rounded-full bg-wood">
          <div className="h-full rounded-full bg-gold" style={{ width: `${Math.round(progress * 100)}%` }} />
        </div>
        <p className="text-xs text-mist">{level >= 100 ? t.maxed : t.toNext(formatSalo(saloToNext(mined), locale))}</p>
      </div>

      <div className="h-2 overflow-hidden rounded-full bg-wood">
        <div className="h-full bg-thread" style={{ width: `${knife}%` }} />
      </div>

      {unclaimed > 0 ? (
        <button type="button" className="h-12 rounded-full bg-gold font-display text-sm text-wood" onClick={onClaim}>
          {t.claim}
        </button>
      ) : null}

      <section>
        <div className="mb-2 flex items-baseline justify-between">
          <h2 className="text-base">{t.pigs}</h2>
          <p className="text-xs text-mist">{pigReady ? t.pigGo : t.pigWait(String(mins))}</p>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {[0, 1, 2].map((index) => (
            <button
              key={index}
              type="button"
              onClick={onPig}
              className={`waddle rounded-2xl border p-1 ${index === 1 ? "waddle-2" : ""} ${index === 2 ? "waddle-3" : ""} ${pigReady ? "border-gold" : "border-line opacity-70"}`}
              aria-label={t.pigs}
            >
              <img src="/art/pig.jpg" alt="" className="aspect-square w-full rounded-xl object-cover" />
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-line bg-bark px-2 py-3 text-center">
      <p className="text-xs text-mist">{label}</p>
      <p className="mt-1 font-display text-sm tabular-nums text-cream">{value}</p>
    </div>
  );
}

function TasksScreen({
  t,
  locale,
  opened,
  claimed,
  daily,
  onOpen,
  onChannel,
  onDaily,
}: {
  t: Dict;
  locale: string;
  opened: boolean;
  claimed: boolean;
  daily: { ready: boolean; reward: number; wait: number; nextStreak: number };
  onOpen: () => void;
  onChannel: () => void;
  onDaily: () => void;
}) {
  return (
    <div className="flex flex-col gap-3">
      <article className="rounded-2xl border border-line bg-bark p-4">
        <h2 className="text-xl">{t.channelTitle}</h2>
        <p className="mt-2 text-sm text-mist">{t.channelBody}</p>
        {claimed ? (
          <p className="mt-4 text-sm text-gold">{t.channelDone}</p>
        ) : (
          <div className="mt-4 flex flex-col gap-2">
            <a
              href={CHANNEL_URL}
              target="_blank"
              rel="noopener noreferrer"
              onClick={onOpen}
              className="inline-flex h-12 items-center justify-center rounded-full border border-gold text-sm text-gold"
            >
              {t.channelGo}
            </a>
            {opened ? (
              <button type="button" className="h-12 rounded-full bg-gold font-display text-sm text-wood" onClick={onChannel}>
                {t.channelClaim}
              </button>
            ) : null}
          </div>
        )}
      </article>

      <article className="rounded-2xl border border-line bg-bark p-4">
        <h2 className="text-xl">{t.dailyTitle}</h2>
        <p className="mt-2 text-sm text-mist">{t.dailyBody}</p>
        <p className="mt-3 font-display text-sm text-gold">{t.streak(daily.nextStreak)}</p>
        {daily.ready ? (
          <button type="button" className="mt-4 h-12 w-full rounded-full bg-gold font-display text-sm text-wood" onClick={onDaily}>
            {t.dailyClaim} {formatSalo(daily.reward, locale)}
          </button>
        ) : (
          <p className="mt-4 text-sm text-mist">{t.dailyWait(formatWait(daily.wait))}</p>
        )}
      </article>
    </div>
  );
}

function VaultScreen({
  t,
  locale,
  komora,
  unclaimed,
  onClaim,
}: {
  t: Dict;
  locale: string;
  komora: number;
  unclaimed: number;
  onClaim: () => void;
}) {
  return (
    <div className="flex flex-col gap-3">
      <article className="rounded-2xl border border-gold bg-bark p-5">
        <h2 className="text-xl">{t.vaultTitle}</h2>
        <p className="mt-4 font-display text-4xl tabular-nums text-cream">{formatSalo(komora, locale)}</p>
        <p className="text-sm text-gold">$SALO</p>
        <p className="mt-3 text-sm text-mist">{t.vaultLead}</p>
        <p className="mt-2 text-sm text-mist">
          {t.inMine}: {formatSalo(unclaimed, locale)}
        </p>
        {unclaimed > 0 ? (
          <button type="button" className="mt-4 h-12 w-full rounded-full bg-gold font-display text-sm text-wood" onClick={onClaim}>
            {t.claim}
          </button>
        ) : null}
      </article>
      <p className="px-1 text-xs leading-relaxed text-mist">{t.vaultNote}</p>
    </div>
  );
}

function SettingsScreen({
  t,
  lang,
  sound,
  onLang,
  onSound,
}: {
  t: Dict;
  lang: Lang;
  sound: boolean;
  onLang: (lang: Lang) => void;
  onSound: () => void;
}) {
  const langs: Lang[] = ["uk", "en", "pl", "de", "ru"];
  return (
    <div className="flex flex-col gap-3">
      <article className="rounded-2xl border border-line bg-bark p-4">
        <h2 className="text-xl">{t.language}</h2>
        <div className="mt-3 flex flex-col gap-2">
          {langs.map((code) => (
            <button
              key={code}
              type="button"
              aria-pressed={lang === code}
              onClick={() => onLang(code)}
              className={`h-12 rounded-full px-4 text-left text-sm ${lang === code ? "bg-gold text-wood" : "border border-line text-cream"}`}
            >
              {langLabel[code]}
            </button>
          ))}
        </div>
      </article>
      <article className="rounded-2xl border border-line bg-bark p-4">
        <h2 className="text-xl">{t.sound}</h2>
        <button type="button" onClick={onSound} className="mt-3 flex h-12 w-full items-center justify-center gap-2 rounded-full bg-gold text-sm text-wood">
          {sound ? <Volume2 className="size-5" aria-hidden="true" /> : <VolumeX className="size-5" aria-hidden="true" />}
          {sound ? t.on : t.off}
        </button>
      </article>
      <article className="rounded-2xl border border-line bg-bark p-4">
        <h2 className="text-xl">{t.how}</h2>
        <p className="mt-2 text-sm leading-relaxed text-mist">{t.howBody}</p>
      </article>
    </div>
  );
}

function DockButton({
  active,
  label,
  onClick,
  children,
}: {
  active: boolean;
  label: string;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-current={active ? "page" : undefined}
      className={`flex min-h-14 flex-col items-center justify-center gap-1 text-xs ${active ? "text-gold" : "text-mist"}`}
    >
      {children}
      {label}
    </button>
  );
}
