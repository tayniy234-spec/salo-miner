import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  ArrowUpRight,
  CalendarRange,
  Gem,
  Layers,
  Pickaxe,
  Radio,
  Send,
  Timer,
  Vault,
} from "lucide-react";
import { BOT_URL, copy, locales, type Dict, type Lang } from "@/lib/copy";

const BASE_PER_HOUR = 25;
const LANGS: Lang[] = ["uk", "ru", "en"];
const FLOOR_ICONS = [Pickaxe, Layers, Gem, Vault, CalendarRange];

function formatLoot(n: number, locale: string, digits: number) {
  return n.toLocaleString(locale, {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });
}

function Spark({ data }: { data: number[] }) {
  const w = 320;
  const h = 76;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const span = max - min || 1;
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * w;
    const y = h - ((v - min) / span) * (h - 10) - 4;
    return [x, y] as const;
  });
  const line = pts
    .map(([x, y], i) => `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`)
    .join(" ");
  const area = `${line} L${w},${h} L0,${h} Z`;

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-16 w-full text-cyan" aria-hidden="true">
      <path d={area} fill="currentColor" opacity="0.16" />
      <path d={line} fill="none" stroke="currentColor" strokeWidth="2" />
    </svg>
  );
}

function BotLink({
  children,
  className,
}: {
  children: ReactNode;
  className: string;
}) {
  return (
    <a href={BOT_URL} target="_blank" rel="noopener noreferrer" className={className}>
      {children}
      <Send className="size-4" aria-hidden="true" />
    </a>
  );
}

const ctaClass =
  "inline-flex h-12 items-center justify-center gap-2 rounded-full bg-gold px-5 font-display text-sm font-medium text-void transition-opacity hover:opacity-90";

export function Site() {
  const [lang, setLang] = useState<Lang>("uk");
  const [mult, setMult] = useState(1);
  const [hours, setHours] = useState(24);
  const [floor, setFloor] = useState(0);
  const [faq, setFaq] = useState<number | null>(0);
  const [mined, setMined] = useState(0);
  const [samples, setSamples] = useState<number[]>(() => Array.from({ length: 32 }, () => 0));

  const t: Dict = copy[lang];
  const locale = locales[lang];

  useEffect(() => {
    const saved = window.localStorage.getItem("lv-lang");
    if (saved === "uk" || saved === "ru" || saved === "en") setLang(saved);
    document.documentElement.lang = saved === "ru" || saved === "en" || saved === "uk" ? saved : "uk";
  }, []);

  useEffect(() => {
    document.documentElement.lang = lang;
    window.localStorage.setItem("lv-lang", lang);
  }, [lang]);

  useEffect(() => {
    const step = (BASE_PER_HOUR * mult) / 3600 / 5;
    const id = window.setInterval(() => {
      setMined((v) => v + step);
    }, 200);
    return () => window.clearInterval(id);
  }, [mult]);

  useEffect(() => {
    const id = window.setInterval(() => {
      setSamples((prev) => {
        const last = prev[prev.length - 1] ?? 0;
        const next = prev.slice(1);
        next.push(last + (BASE_PER_HOUR * mult) / 3600);
        return next;
      });
    }, 1000);
    return () => window.clearInterval(id);
  }, [mult]);

  const perHour = BASE_PER_HOUR * mult;
  const perDay = perHour * hours;
  const perWeek = perHour * hours * 7;

  const stats = useMemo(
    () => [
      { label: t.perHour, value: formatLoot(perHour, locale, perHour >= 100 ? 0 : 1) },
      { label: t.perDay, value: formatLoot(perDay, locale, 0) },
      { label: t.perWeek, value: formatLoot(perWeek, locale, 0) },
    ],
    [t.perHour, t.perDay, t.perWeek, perHour, perDay, perWeek, locale],
  );

  return (
    <div className="min-h-svh bg-void text-ivory">
      <header className="sticky top-0 z-30 border-b border-line bg-void/90 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center gap-4 px-4">
          <a href="#top" className="flex items-center gap-3">
            <img
              src="/art/medallion.jpg"
              alt=""
              className="hex size-9 object-cover"
            />
            <span className="font-display text-sm font-medium tracking-wide">LootVault</span>
          </a>
          <nav className="ml-auto hidden items-center gap-5 text-sm text-mist md:flex">
            <a href="#how" className="hover:text-ivory">
              {t.nav.how}
            </a>
            <a href="#tower" className="hover:text-ivory">
              {t.nav.tower}
            </a>
            <a href="#calc" className="hover:text-ivory">
              {t.nav.calc}
            </a>
            <a href="#token" className="hover:text-ivory">
              {t.nav.token}
            </a>
            <a href="#faq" className="hover:text-ivory">
              {t.nav.faq}
            </a>
          </nav>
          <LangSwitch lang={lang} onChange={setLang} />
          <div className="hidden md:flex md:items-center">
            <BotLink className={ctaClass}>{t.cta}</BotLink>
          </div>
        </div>
      </header>

      <main id="top" className="pb-24 md:pb-0">
        <section className="relative overflow-hidden">
          <img
            src="/art/vault.jpg"
            alt="Кібер-сховище LootVault: золоті ворота і ціанові промені"
            className="absolute inset-0 h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-void/60 md:bg-void/40" />
          <div className="absolute inset-y-0 left-0 hidden w-3/5 bg-gradient-to-r from-void via-void/80 to-transparent md:block" />

          <div className="relative mx-auto grid max-w-6xl gap-6 px-4 py-8 md:grid-cols-12 md:gap-8 md:py-16">
            <div className="md:col-span-7">
              <p className="mb-4 inline-flex items-center gap-2 text-xs font-medium uppercase tracking-widest text-cyan">
                <Radio className="live-dot size-3.5" aria-hidden="true" />
                {t.live}
              </p>
              <p className="mb-3 text-sm text-gold">{t.kicker}</p>
              <h1 className="max-w-xl text-4xl leading-tight text-ivory sm:text-5xl">{t.h1}</h1>
            </div>

            <div className="md:col-span-5 md:row-span-2">
              <MinerCard
                t={t}
                locale={locale}
                mined={mined}
                samples={samples}
                perHour={perHour}
                mult={mult}
              />
            </div>

            <div className="md:col-span-7">
              <p className="max-w-xl text-base leading-relaxed text-mist">{t.lead}</p>
              <div className="mt-6 flex flex-col gap-3 sm:flex-row">
                <BotLink className={ctaClass}>{t.cta}</BotLink>
                <a
                  href="#calc"
                  className="inline-flex h-12 items-center justify-center gap-2 rounded-full border border-line px-5 text-sm text-ivory hover:border-gold"
                >
                  {t.cta2}
                  <ArrowUpRight className="size-4" aria-hidden="true" />
                </a>
              </div>
              <ul className="mt-6 flex flex-wrap gap-2">
                {t.facts.map((fact) => (
                  <li
                    key={fact}
                    className="rounded-full border border-line bg-ink/80 px-3 py-2 text-xs text-ivory"
                  >
                    {fact}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        <section id="how" className="mx-auto max-w-6xl px-4 py-16">
          <h2 className="text-3xl text-ivory">{t.howTitle}</h2>
          <p className="mt-3 max-w-2xl text-mist">{t.howLead}</p>
          <ol className="mt-8 grid gap-3 md:grid-cols-4">
            {t.steps.map((step, i) => (
              <li key={step.title} className="rounded-card border border-line bg-ink p-5">
                <p className="font-display text-sm text-gold">0{i + 1}</p>
                <h3 className="mt-4 text-lg text-ivory">{step.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-mist">{step.body}</p>
              </li>
            ))}
          </ol>
        </section>

        <section id="tower" className="border-y border-line bg-ink">
          <div className="mx-auto grid max-w-6xl gap-8 px-4 py-16 md:grid-cols-12">
            <div className="md:col-span-4">
              <h2 className="text-3xl">{t.towerTitle}</h2>
              <p className="mt-3 text-mist">{t.towerLead}</p>
            </div>
            <div className="md:col-span-8">
              <div className="flex flex-col gap-2">
                {t.floors.map((item, i) => {
                  const Icon = FLOOR_ICONS[i] ?? Timer;
                  const open = floor === i;
                  return (
                    <button
                      key={item.title}
                      type="button"
                      aria-expanded={open}
                      onClick={() => setFloor(i)}
                      className={
                        "rounded-card border px-4 py-4 text-left transition-colors " +
                        (open
                          ? "border-gold bg-panel text-ivory"
                          : "border-line bg-void text-mist hover:border-gold-deep")
                      }
                    >
                      <span className="flex items-center gap-3">
                        <Icon className={open ? "size-5 text-gold" : "size-5"} aria-hidden="true" />
                        <span className="font-display text-sm text-ivory">
                          {i + 1}. {item.title}
                        </span>
                      </span>
                      {open ? <span className="mt-3 block text-sm leading-relaxed text-mist">{item.body}</span> : null}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </section>

        <section id="calc" className="mx-auto grid max-w-6xl gap-8 px-4 py-16 md:grid-cols-12">
          <div className="md:col-span-5">
            <h2 className="text-3xl">{t.calcTitle}</h2>
            <p className="mt-3 text-mist">{t.calcLead}</p>
            <p className="mt-6 text-sm text-mist">{t.calcNote}</p>
          </div>
          <div className="rounded-card border border-line bg-ink p-5 md:col-span-7">
            <label htmlFor="mult" className="flex items-baseline justify-between gap-3">
              <span className="text-sm text-mist">{t.mult}</span>
              <span className="font-display text-2xl tabular-nums text-gold">
                {mult === 1 ? t.bronze : `×${mult}`}
              </span>
            </label>
            <input
              id="mult"
              type="range"
              min={1}
              max={10}
              step={1}
              value={mult}
              onChange={(e) => setMult(Number(e.target.value))}
            />
            <label htmlFor="hours" className="mt-2 flex items-baseline justify-between gap-3">
              <span className="text-sm text-mist">{t.hours}</span>
              <span className="font-display text-2xl tabular-nums">{hours}</span>
            </label>
            <input
              id="hours"
              type="range"
              min={1}
              max={24}
              step={1}
              value={hours}
              onChange={(e) => setHours(Number(e.target.value))}
            />
            <dl className="mt-4 grid grid-cols-3 gap-2">
              {stats.map((stat) => (
                <div key={stat.label} className="rounded-2xl border border-line bg-void px-3 py-3">
                  <dt className="text-xs text-mist">{stat.label}</dt>
                  <dd className="mt-1 font-display text-lg tabular-nums text-ivory sm:text-xl">
                    {stat.value}
                  </dd>
                  <dd className="text-xs text-gold">LOOT</dd>
                </div>
              ))}
            </dl>
          </div>
        </section>

        <section id="token" className="border-t border-line">
          <div className="mx-auto grid max-w-6xl items-center gap-8 px-4 py-16 md:grid-cols-2">
            <img
              src="/art/medallion.jpg"
              alt="Золотий шестикутний медальйон LootVault"
              className="mx-auto w-full max-w-sm rounded-card border border-line object-cover"
            />
            <div>
              <p className="text-sm text-cyan">{t.tokenKicker}</p>
              <h2 className="mt-2 text-3xl">{t.tokenTitle}</h2>
              <p className="mt-4 text-mist">{t.tokenLead}</p>
              <ul className="mt-6 flex flex-col gap-2">
                {t.tokenPoints.map((point) => (
                  <li key={point} className="flex items-center gap-3 text-sm">
                    <Timer className="size-4 text-gold" aria-hidden="true" />
                    {point}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        <section id="faq" className="mx-auto max-w-6xl px-4 py-16">
          <h2 className="text-3xl">{t.faqTitle}</h2>
          <div className="mt-6 divide-y divide-line border-y border-line">
            {t.faqs.map((item, i) => {
              const open = faq === i;
              return (
                <div key={item.q}>
                  <button
                    type="button"
                    aria-expanded={open}
                    onClick={() => setFaq(open ? null : i)}
                    className="flex w-full items-center justify-between gap-4 py-4 text-left"
                  >
                    <span className="font-display text-base text-ivory">{item.q}</span>
                    <span className="text-gold" aria-hidden="true">
                      {open ? "–" : "+"}
                    </span>
                  </button>
                  {open ? <p className="pb-4 text-sm leading-relaxed text-mist">{item.a}</p> : null}
                </div>
              );
            })}
          </div>
        </section>

        <section className="bg-gold text-void">
          <div className="mx-auto flex max-w-6xl flex-col items-start gap-5 px-4 py-14 md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="text-3xl text-void">{t.finalTitle}</h2>
              <p className="mt-2 text-gold-deep">{t.finalLead}</p>
            </div>
            <a
              href={BOT_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex h-12 items-center justify-center gap-2 rounded-full bg-void px-5 font-display text-sm text-gold"
            >
              {t.cta}
              <Send className="size-4" aria-hidden="true" />
            </a>
          </div>
        </section>
      </main>

      <footer className="border-t border-line px-4 py-8">
        <div className="mx-auto flex max-w-6xl flex-col gap-3 text-xs leading-relaxed text-mist">
          <p>{t.disclaimer}</p>
          <p>{t.refLine}</p>
        </div>
      </footer>

      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-void/95 p-3 md:hidden">
        <BotLink className={`${ctaClass} w-full`}>{t.cta}</BotLink>
      </div>
    </div>
  );
}

function LangSwitch({ lang, onChange }: { lang: Lang; onChange: (lang: Lang) => void }) {
  return (
    <div className="ml-auto flex rounded-full border border-line p-1 md:ml-0" role="group" aria-label="Language">
      {LANGS.map((code) => (
        <button
          key={code}
          type="button"
          aria-pressed={lang === code}
          onClick={() => onChange(code)}
          className={
            "h-8 min-w-10 rounded-full px-2 text-xs uppercase " +
            (lang === code ? "bg-gold text-void" : "text-mist")
          }
        >
          {code}
        </button>
      ))}
    </div>
  );
}

function MinerCard({
  t,
  locale,
  mined,
  samples,
  perHour,
  mult,
}: {
  t: Dict;
  locale: string;
  mined: number;
  samples: number[];
  perHour: number;
  mult: number;
}) {
  return (
    <aside className="relative rounded-card border border-gold/40 bg-ink p-5">
      <span className="pointer-events-none absolute top-3 left-3 h-4 w-4 border-t border-l border-gold" />
      <span className="pointer-events-none absolute right-3 bottom-3 h-4 w-4 border-r border-b border-gold" />
      <div className="flex items-center justify-between gap-3">
        <p className="font-display text-sm">{t.minerTitle}</p>
        <p className="inline-flex items-center gap-2 text-xs text-cyan">
          <span className="live-dot size-2 rounded-full bg-cyan" />
          {t.minerStatus}
        </p>
      </div>
      <p className="mt-6 text-xs text-mist">{t.session}</p>
      <p className="mt-1 font-display text-4xl tabular-nums text-ivory">
        {formatLoot(mined, locale, 4)}
      </p>
      <p className="text-sm text-gold">LOOT</p>
      <Spark data={samples} />
      <div className="mt-2 flex items-center justify-between text-sm">
        <span className="text-mist">
          {formatLoot(perHour, locale, perHour >= 100 ? 0 : 1)} LOOT / h
        </span>
        <span className="font-display text-gold">{mult === 1 ? t.bronze : `×${mult}`}</span>
      </div>
      <p className="mt-4 text-xs leading-relaxed text-mist">{t.holdNote}</p>
    </aside>
  );
}
